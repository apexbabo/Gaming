sharing the ahk v2 and cfg scripts used in https://www.youtube.com/watch?v=nc1McitBlUg
which is a video response to https://www.reddit.com/r/GlobalOffensive/comments/1mkm7hl/bullets_go_back_in_time_input_time_travel_cs2/

Map is Angle Hold Trainer CS2 https://steamcommunity.com/sharedfiles/filedetails/?id=3070452391
great fps for tests; even features a rudimentary reaction time measure (if you can't do 11 and below, delete the game :P)